MATCOM Overleaf source package - 2026-10-14

Main file: manuscript.tex
Compiler: pdfLaTeX.
The BMB Springer class has been retained for format-free preliminary submission; this is NOT a validated elsarticle conversion.
All five PDF figures and the class file are included. Bibliography is embedded in manuscript.tex.
No scientific results, tables, manuscript text or figures have been changed. The package uses the 2026-10-12 BMB submission source and its S1 evidence.
Compile in Overleaf and inspect the output and warnings. Confirm current MATCOM author requirements and obtain both authors' approval before submission.
