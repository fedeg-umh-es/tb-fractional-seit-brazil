TB-SEIT manuscript for Overleaf (author-review draft, not submission ready)

1. Upload this zip as a new Overleaf project.
2. Main document: manuscript.tex. Compiler: pdfLaTeX. Bibliography: BibTeX (the project must run
   pdflatex, bibtex, pdflatex, pdflatex; Overleaf does this automatically).
3. sn-mathphys-ay.bst is the Springer style with ONE local change (see the comment at the top of the file):
   it makes the reference list sort by surname (the stock file listed Kharazmi before Kalizhanova).
4. Placeholders left on purpose: [ZENODO_DOI] and [RELEASE_TAG] (Code and Data Availability).
5. LaTeX comments starting with "AUTHOR-ACTION" mark text that depends on a decision of the authors.
6. This package was assembled without compiling it. Please check the compile log for warnings,
   especially: overfull boxes in the wide tables (they use \resizebox), the appendix tables, and the reference order.
