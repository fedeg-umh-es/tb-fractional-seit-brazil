# TB Fractional SEIT — Brazil | Springer Nature LaTeX author-review package

**Status:** Editorially typeset author-review draft, **NOT SUBMISSION READY**.

This package was built from the integrated V2 manuscript uploaded in the conversation. It uses the user's **December 2024** Springer Nature `sn-jnl` LaTeX class with author–year citations, continuous line numbering, five tables, and figure callouts. The paper's frozen numerical results have **not been recalculated** or altered.

## Build

Use `pdflatex manuscript.tex`, then `bibtex manuscript` (or `bibtex8 manuscript` where available), then `pdflatex manuscript.tex` twice. The compiled draft is `manuscript.pdf` (21 pages). The `.tex`, `.bib`, `.bst`, and `.cls` files are editable and bundled.

## Figures still required (editorial V2 binary assets not uploaded)

The user's uploaded integrated manuscript names the five editorial PNGs, but those files were not supplied. The PDF shows conspicuous labeled boxes rather than fabricated figures. Copy the **already verified** PNGs from the integrated V2 `figures_editorial/` folder into this package's `figures/`, keeping exact names:

1. `F1_global_open_loop.png`
2. `F2_rolling_RMSE.png`
3. `F3_fractional_skill.png`
4. `F4_alpha_profiles.png`
5. `F5_R0_explored_pool.png`

The `\IfFileExists` declarations load these files automatically without touching any scientific data. After supplying them, recompile and visually review all graphics and captions. This ZIP does not purport to contain the five frozen/verified figures; **do not submit it as-is**.

## Authorship

Two authors' names, institutional e-mails and ORCID IDs are populated from public author metadata and relevant account correspondence. **Order (Amaury then Federico) and corresponding author (Federico) are PROVISIONAL** pending an explicit author decision; neither is inferred as a final agreement from project documents. Affiliations are grounded in academic publisher pages and an institutional directory. Check exact department naming with authors before submission.

## Scientific/editorial limitations

Funding, competing interests, CRediT contributions, and the institutional ethics-applicability statement remain subject to author confirmation, as do the access and reuse conditions for the corrected S1 evidence package and the public Excel. These cannot ethically be invented by the assistant. Historical manuscript numerical values `1117.960`, `1759.538` and `h=7` were removed from narrative commentary, not from historical archived evidence. The updated paper continues to distinguish the model provider's DATASUS attribution from the unrecovered exact original query.

See `EDITORIAL_REPAIR_REPORT.md` for a complete repair and verification log.
