Copy the five unchanged verified editorial PNG files from the V2 figures_editorial directory here.

F1_global_open_loop.png
F2_rolling_RMSE.png
F3_fractional_skill.png
F4_alpha_profiles.png
F5_R0_explored_pool.png

The PDF has conspicuous placeholders until these exact files are present. Do not generate new estimates or silently substitute historical/pre-S1 figures.
