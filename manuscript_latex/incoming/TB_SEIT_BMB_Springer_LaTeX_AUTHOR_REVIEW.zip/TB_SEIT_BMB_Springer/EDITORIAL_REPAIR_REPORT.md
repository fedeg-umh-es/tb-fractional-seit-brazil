# Editorial repair log — integrated V2 to Springer LaTeX working draft

Date: 10 October 2026. Inputs: V2 integrated manuscript uploaded as `Texto pegado.txt`, and the author's Springer Nature December 2024 `.zip` template. No repository files or frozen evidence were changed.

## Completed

1. Replaced author/title-page placeholders with verified identifiers:
   - Amaury de Souza; Universidade Federal de Mato Grosso do Sul, Instituto de Física, Campo Grande, Brazil; `amaury.souza@ufms.br`; ORCID `0000-0001-8168-1482`.
   - Francisco Federico García Crespi; Universidad Miguel Hernández de Elche, Department of Computer Engineering, Elche, Spain; `fedeg@umh.es`; ORCID `0000-0002-7129-7791`.
   - **Author order and corresponding author designation are provisional pending approval.**
2. Corrected Code Availability: base GitHub repository is public; separately frozen S1 evidence-producing executors are not established as a public deposit. Distinguished the base repository head from the corrected evidence manifest. Retained technical provenance record names and omitted hard-to-read executor digests from main-paper prose; file-level digests remain in the cited archived provenance manifest, not recomputed here.
3. Data Availability acknowledges the collaborator's declared DATASUS/SINAN origin and her general monthly aggregation account, separately from the failed reconstruction of the exact original query. Conserved C1–C4 and 99/264 discordant C1 months; retained the C4 duplicated screenshot disclosure and alternate documentary supports.
4. Removed historical/obsolete result-comparison text (`1117.960`, `1759.538`, former seasonal-naive `h=7`, old stability classification). Current numerical S1 values and interpretive restrictions remain unchanged.
5. Clarified earlier SEIT conceptual source as an unpublished collaborative working manuscript (not a verified published reference). Added one relevant verified historical fractional epidemic formulation citation, Area et al. (2015), to Introduction; retained the Diethelm, Ford and Freed (2002) methodological citation. BibTeX contains six cited published sources; none were restored for padding.
6. Adopted official Springer Nature December 2024 `sn-jnl` template, `sn-mathphys-ay` author–year citations, continuous line numbering and sequential page numbers, original text flow (Introduction, Methods, Results, Discussion, Conclusions), five tables and five figure callouts, and 'Statements and Declarations'. Six keywords and a 198-word abstract preserved.
7. Replaced unsupported human-declaration placeholders with explicitly **pending** factual statements. No funding, non-conflict, authorship contribution or ethics decision was assumed.
8. Compiled with `pdflatex` and `bibtex8`, then two final `pdflatex` passes: 21-page output, references resolved, no LaTeX errors or overfull boxes in final pass.

## Missing external assets and decisions — do not submit yet

- All five actual editorial figures must be copied from the author's V2 package. None were available in the attached Markdown or the supplied Springer template; current PDF contains visible file-missing markers. Do not substitute newly inferred trajectories or mechanistic classifications.
- Author confirmation required: final author list/order, corresponding author, formal English affiliation strings, contributions, funding, competing interests, ethics wording and definitive code/data access terms.
- Base repository is publicly accessible; this does **not** confer permission to reuse the original observational spreadsheet. Original extraction filters are unrecovered despite the documented C1–C4 reconstruction audit.

## Verified public identifiers

- Federico García Crespi, ORCID `0000-0002-7129-7791`, UMH / Computer Engineering, institutional email `fedeg@umh.es`: 2026 publisher page https://doi.org/10.1002/cae.70196 and UMH department directory.
- Amaury de Souza, ORCID `0000-0001-8168-1482`, UFMS / Physics, email `amaury.souza@ufms.br`: ORCID profile and academic publications, plus direct collaboration correspondence.
- Bulletin of Mathematical Biology: https://link.springer.com/journal/11538/submission-guidelines
- Springer author support: https://www.springernature.com/in/authors/campaigns/latex-author-support

## Integrity boundary

The scientific evidence freeze itself (285 files), frozen figures, rolling forecasts (780), or executor digests were **not directly accessible in this runtime**, and therefore have not been rehashed or revalidated here. The user-provided V2 reported those checks passing. This work only altered an isolated editorial derivative and performed structural/compilation verification.
