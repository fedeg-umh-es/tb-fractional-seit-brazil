#!/bin/sh
set -eu
pdflatex -interaction=nonstopmode -halt-on-error manuscript.tex
if command -v bibtex >/dev/null 2>&1; then bibtex manuscript; else bibtex8 manuscript; fi
pdflatex -interaction=nonstopmode -halt-on-error manuscript.tex
pdflatex -interaction=nonstopmode -halt-on-error manuscript.tex
